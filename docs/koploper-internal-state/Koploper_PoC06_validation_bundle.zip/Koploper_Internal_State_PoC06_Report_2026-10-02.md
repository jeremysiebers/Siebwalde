# Koploper Internal State PoC 06 — video/trace cross-validation

Date: 2026-10-02. Scope: standard Koploper demo layout, simulation; read-only probe PoC05 v0.3.0. No modification of Koploper or live track outputs.

## Sources and synchronization

- Raw user inputs: `output_v03(1).zip`, `Recording 2026-10-02 154813.mp4`.
- Video H.264 912×950, 30 fps, 101.467 s. Embedded creation time `2026-10-02T13:46:28Z` (= 15:46:28 CEST), consistent with visible communication-log times.
- Probe: `2026-10-02T13:46:33.3329269Z` through `2026-10-02T13:48:03.4608533Z`, 304 snapshots × 30 blocks, 3 locomotives = 9,120 block records and 912 locomotive records.
- Video-relative times are approximate snapshots, not exact simultaneously sampled GUI data.

## Established mapping

At the probe's initial snapshot, visible/current blocks 18,20,9 correspond to internal locomotive IDs 24,8,2, respectively (first/second/third GUI rows in the recording). The *internal* block ID is not generally the same as the GUI display number: notably internal ID 30 => visible block 2, internal 22 => visible 25, 23=>22, 24=>23, 25=>24, 31=>30. Always map by `DisplayBlockCandidate` (to be verified per database) and not array/list position.

## Video and probe cross-checks

| Video position | GUI current → next (in Overview Locomotives) | Internal loc ID | Probe status 2 (display block) | Probe status 1 (display blocks) | Interpretation |
|---|---|---:|---:|---|---|
| ~00:10 | 9 → 10 | 2 | 9 | 10, 11 | GUI next matches one reserved block; probe detects a second future block |
| ~00:20 | 11 → 12 | 2 | 11 | 12 | Agreement |
| ~00:30 | 1 → 2 | 24 | 1 | 2 | Agreement, after resolving internal block ID 30 → visible 2 |
| ~00:40 | 3 → 6 | 24 | 3 | 6 | Agreement |
| ~01:30 | 21 → 19 | 8 | 21 | 19, 11 | Agreement; other future block also present |

GUI current → next is independent corroboration for the *next intended block*, not direct proof of **every** reserved future block or an API-level Koploper reservation ownership declaration. Yellow/red track drawing is not treated as authoritative without documented color semantics.

## State changes and timing

After 30 INITIAL event records, 88 CHANGED events:
- 0→1: 23
- 1→2: 22
- 2→9: 22
- 9→0: 21

All 22 recorded transitions `1→2` retained the same locomotive owner; all status 1 / 2 samples have a non-null locomotive owner. Matching 22 reservation-start-to-occupation delays: mean 4.940 seconds, median 4.603 seconds, range 2.031–10.113 seconds. The 10.113-second event occurs when a second future block was reserved ahead of time. One observed reservation (internal block 11 for loc-ID 8, at 15:47:55.634) remains status 1 at recording end; this is not an observed cancellation.

Maximum simultaneously reserved per locomotive: 2. At some snapshots more than one locomotive has a status-1 block; no duplicate block record/owner conflict appeared in the sampled dataset. This is *not* a full concurrent-contention stress test.

## Acceptance status

- A — reserve a future block, correct owner, and corroborating GUI next block: **PASS for tested normal simulation paths**.
- B — status 1 followed by status 2, same locomotive owner: **PASS for 22 observed completed paths**.
- C — deliberate reservation cancellation *without occupation*: **NOT TESTED** (no 1→0/9 cancellation transitions in this capture). A separate controlled scenario is required.
- D — multi-locomotive observation: **PARTIAL PASS** (concurrent reservations and no observed collisions, no deliberate conflict/invalidation stress).
- Physical amplifier/PWM readiness: **NOT VALIDATED**. These are Koploper administrative states, not independent physical occupancy. No actuation authority should follow from this PoC.

## Required engineering follow-up

1. Preserve separate state values for 0, 1, 2, 9; do not treat 9 as proven `FREE`.
2. Probe is snapshot-based (nominal `-IntervalMs 200`, effective circa 304 snapshots/90 s), not atomic; gate implausible and incoherent observations.
3. Validate deliberate reserve → cancel without occupation and two-loco contention using the simulator; ideally cross-check one block/loc pair with Koploper's `Blok is gereserveerd door locomotief` logical condition.
4. Observer must bind to validated executable version/hash, resolve root dynamically after start/restart, map internal IDs to GUI block IDs and then to physical amplifiers, and treat stale/failed reads as UNKNOWN. Keep hardware occupancy and the existing safety interlocks authoritative.
5. A set of reserved blocks does not automatically provide an ordered route; obtain order from the graph and/or separately verified route state if necessary.

**Conclusion:** High-confidence functional validation of the 0/1/2/9 normal operating trajectory and current/next block mapping in the simulator; PoC06 is not fully closed until cancellation and explicit owner ground truth are tested.
