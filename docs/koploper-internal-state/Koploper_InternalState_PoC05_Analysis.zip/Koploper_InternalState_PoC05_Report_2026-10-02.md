# Koploper Internal State — PoC 05 analyse

Datum: 2026-10-02 · Test: standaard Koploper 9.4-simulatiebaan · Status: read-only runtime-observatie.

## Samenvatting

De eerder geïdentificeerde `TBlok+0x1ED`-statusbyte blijkt in de meting het gezochte
reserverings-/bezettingsverloop te onderscheiden. Gecombineerd met de eigenaarspointer
`TBlok+0x1AC` kunnen we **per blok een aan een locomotief toegewezen reservering
vóór administratieve bezetting uitlezen**.

De waargenomen toestanden zijn zeer consistent met:
- `0`: vrij / geen eigenaar;
- `1`: vooraf gereserveerd / eigenaar aanwezig;
- `2`: administratief bezet / eigenaar aanwezig;
- `9`: transitie-/resettoestand / geen eigenaar; **niet automatisch als vrij te gebruiken**.

Dit zijn door zowel eerdere statische codepaden als deze runtime-test ondersteunde
betekenissen. Voor productie-/PWM-gebruik volgt nog een afzonderlijke
functionele vergelijking met Koplopers eigen statusinterface en een fysieke safety-validatie.

## Datakwaliteit

- EXE SHA-256: `645B4681C14975F3619EB44968C74F3B7925CB914C5A23302932918D73079D2E`.
- Rootobject tijdens deze run: `0x028A981C` (**proces-/run-afhankelijk; niet hardcoden**).
- 305 volledige snapshots, sequence 0–310 met zes overgeslagen sequencenummers.
- 30 blokken × 305 = 9.150 blokrecords; 3 locs × 305 = 915 locrecords.
- Meetduur: 90,055 seconden.
- Gevraagd pollinterval 200 ms; *waargenomen gemiddeld* circa 296 ms,
  met incidentele gaten tot circa 580 ms. Daarom niet als realtime safety-interface gebruiken.
- 94 gewijzigde blokevents, exclusief 30 INITIAL-events.

## Overgangen gedurende meting

| Vorige status | Nieuwe status | Aantal | Interpretatie |
|---:|---:|---:|---|
| 0 | 1 | 23 | Nieuwe voorafgaande reservering |
| 9 | 1 | 2 | Herreservering vanuit transitie |
| 1 | 2 | 24 | Overgang reservering naar administratieve bezetting |
| 2 | 9 | 24 | Opheffen oude administratieve bezetting |
| 9 | 0 | 21 | Reset naar vrij |

Alle 382 `status=1`-records en 915 `status=2`-records hebben een herleidbare
locomotiefeigenaar. Alle 7.454 `status=0`- en 399 `status=9`-records hebben géén
locomotiefeigenaar. Op alle 305 snapshots hebben alle drie de locs precies één
`status=2`-blok.

Er zijn 25 nieuw geobserveerde reserveringen, waarvan er 24 in dezelfde meting naar
status 2 overgaan. De resterende reservering (`loc 24`, blok 12) is aan het einde
van de capture nog actief.

## Anticipatie: 24 gereserveerd → bezet

In alle 24 episodes ging een blok eerst naar status 1, vervolgens naar status 2,
en bleef dezelfde eigenaar gekoppeld. Gemeten voorsprong tussen *eerste geobserveerde*
status 1 en *eerste geobserveerde* status 2:

- Minimum: 0.858 s.
- Gemiddelde: 4.589 s.
- Mediaan: 4.415 s.
- Maximum: 9.107 s.

Deze timings bevatten onzekerheid vanwege polling en zijn geen exacte interne
Koploper-transitietijdstippen. De volledige paren staan in
`reservation_to_occupation_pairs.csv`.

## Sleutelvoorbeeld: meerdere toekomstblokken voor één loc

**Locomotief-ID 24**:

| Sequence | Lokale tijd (CEST) | Bezet (status 2) | Vooruit gereserveerd (status 1) |
|---:|---|---:|---|
| 115 | 15:32:15.515 | 17 | 19, 20 |
| 130 | 15:32:19.925 | 19 | 20 |
| 146 | 15:32:24.542 | 20 | 24 |

Op sequence 115 heeft dezelfde loc gelijktijdig eigenaarstatus voor blok 17
en vooruitreserveringen voor **blokken 19 en 20**. In sequence 130 wordt 19
bezet, terwijl 20 gereserveerd blijft; in sequence 146 wordt 20 bezet.
Blok-ID's zijn niet vanzelf een routevolgorde: die moeten we uit
reserveringstijdstippen, topologie of aanvullende interne routegegevens reconstrueren.
Dit voorbeeld bevat een observeerbare volgorde 17 → 19 → 20.

Loc 2 heeft bij sequence 79 bezet blok 17 en reserveringen voor blokken 1 en 18.
Maximaal waargenomen: twee reserveringen tegelijk voor één locomotief.

## Aanvullende vondst: locomotief-object `+0x58`

`Loc+0x58` stemt in 913 van de 915 locrecords overeen met het bijbehorende
administratief bezette (`status=2`) blok. De twee uitzonderingen:
sequence 94, loc 2 (`+0x58`=17 terwijl blok 18 reeds status 2 heeft) en
sequence 130, loc 24 (`+0x58`=17 terwijl blok 19 reeds status 2 heeft).

Dit is passend bij **niet-atomaire snapshots**: het uitlezen van verschillende
objecten kan een overgang op verschillende tijdstippen raken. Niet bewezen dat
het werkelijk de enige verklaring is. `Loc+0x54` liep in meerdere
gevallen met het vorige blok mee en is nog niet semantisch bevestigd.

## Validaties en open punten vóór C# PWM-integratie

1. **Handmatige cross-check**: laat dezelfde standaard simulatiebaan rijden,
   vergelijk live `status=1` voor een bekend blok met Koplopers eigen
   blok-/reserveringenweergave en leg screenshots met tijd vast.
2. **Herhaalde coherente snapshots**: lees bloc-state/eigenaar/tick tweemaal,
   verwerp of herstel inconsistenties. Loc `+0x58` is nuttige extra check,
   maar geen onafhankelijke safety authority.
3. **State 9 apart behandelen**: niet als `FREE` of als geldige reservering
   beschouwen zonder aanvullende validatie; let op directe `9→1`.
4. **Twee locs en conflictsituaties**: aantonen dat eigenaarschap niet
   wordt verwisseld, en dat geannuleerde reserveringen en opnieuw
   uitgegeven reserveringen juist worden gepubliceerd.
5. **Lifetime en start/restart**: rootpointer per sessie opnieuw vaststellen,
   alleen de geverifieerde binary accepteren, geen stale states,
   bij mislukte verificatie géén write-authority.
6. **Timing**: daadwerkelijk gerealiseerde ~296 ms bij gevraagd 200 ms
   is voldoende voor deze PoC, maar geen garantie voor tijdige physical
   control. Bepaal een maximale acceptabele age/latency en een veilige fallback.
7. **Siebwalde**: map interne block-ID expliciet naar amplifieradressen;
   behoud fysieke occupancy, interlocks en de eis
   'verlaten blok → PWM 399'. Reserveringen mogen nooit alléén een
   fysieke PWM-vrijgave autoriseren.
8. **Volgorde en definitie**: test of een vooraf geclaimd blok óók status 1
   krijgt en of dit exact dezelfde definitie is als Koplopers logische actie
   'Blok is gereserveerd door locomotief'. De status 1/2 mapping is
   nu sterk empirisch onderbouwd, maar nog geen formele interface.

## Voorgesteld read-only API-contract (nog niet productiegeschikt)

```json
{
  "source": "Koploper94.ReadOnlyProbe",
  "sequence": 115,
  "consistent": true,
  "locomotives": [
    { "internalLocId": 24, "occupiedBlocks": [17], "reservedBlocks": [19, 20] }
  ],
  "unknownOrTransitionBlocks": [],
  "capturedAtUtc": "<snapshot timestamp>"
}
```

Een toestand `consistent=true` mag pas worden gezet na expliciete
dubbele lezing en checks; de huidige PowerShell-probe produceert niet
gegarandeerd atomaire snapshots.

## Inhoud gegevensbestanden

- `reservation_to_occupation_pairs.csv`: 24 gereserveerd→bezet-episodes en voorsprong.
- `locomotive_trajectory_per_snapshot.csv`: per snapshot en loc bezet blok,
  gereserveerde blokken, locobject-kandidaten en overeenstemmingscheck.
- `raw_transition_events_with_timestamps.csv`: oorspronkelijke events inclusief timestamps.

Bron: door gebruiker aangeleverde `output_v03.zip`, reeks `20261002_153142` (Watch).
De `20261002_153128`-reeks bevat één afzonderlijke Once-snapshot en is niet
meegenomen in de Watch-overgangstellingen.
